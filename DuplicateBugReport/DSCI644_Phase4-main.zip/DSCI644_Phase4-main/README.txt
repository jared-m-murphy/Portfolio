The 3 folders contain the respective code for 3/4 of the research questions addressed in the final project report 
